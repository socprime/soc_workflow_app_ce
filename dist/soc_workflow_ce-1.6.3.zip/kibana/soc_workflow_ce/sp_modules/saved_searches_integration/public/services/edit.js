require('ui/modules').get('app/soc_workflow_ce', []).service('spSavedSearchIntegrationEdit', [function () {
    return false;
}]);
