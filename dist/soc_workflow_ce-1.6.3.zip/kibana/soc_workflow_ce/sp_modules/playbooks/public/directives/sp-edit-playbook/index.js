require('ui/modules').get('app/soc_workflow_ce', []).directive('spEditPlaybook', [function () {
        return {
            template: ''
        }
    }]);
