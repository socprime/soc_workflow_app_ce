let data = {
    'Low': '#1B5E20',
    'Medium': '#FF9800',
    'High': '#F44336',
};

module.exports = data;